-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 02, 2024 at 05:29 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `carzone1`
--

-- --------------------------------------------------------

--
-- Table structure for table `booked`
--

CREATE TABLE `booked` (
  `car_name` varchar(100) DEFAULT NULL,
  `car_nameplate` varchar(50) DEFAULT NULL,
  `car_price` decimal(10,2) DEFAULT NULL,
  `car_age` int(11) DEFAULT NULL,
  `id` int(11) NOT NULL,
  `user` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `booked`
--

INSERT INTO `booked` (`car_name`, `car_nameplate`, `car_price`, `car_age`, `id`, `user`) VALUES
('Lamborghini', 'HP01A0002', 20000000.00, 2023, 9, ''),
('Swift', 'HP01A0002', 800000.00, 2023, 10, ''),
('Hyundai Verna', 'HP01A0001', 1600000.00, 2023, 11, ''),
('Swift', 'HP01A0002', 800000.00, 2023, 12, ''),
('Swift', 'HP01A0002', 800000.00, 2023, 13, ''),
('Alto', 'HP01A0003', 400000.00, 2023, 14, ''),
('Alto', 'HP01A0003', 400000.00, 2023, 15, ''),
('Alto', 'HP01A0003', 400000.00, 2023, 16, ''),
('Alto', 'HP01A0003', 400000.00, 2023, 17, '');

-- --------------------------------------------------------

--
-- Table structure for table `cars`
--

CREATE TABLE `cars` (
  `car_id` int(20) NOT NULL,
  `car_name` varchar(50) NOT NULL,
  `car_nameplate` varchar(50) NOT NULL,
  `car_img` varchar(50) DEFAULT 'NA',
  `car_availability` varchar(10) NOT NULL,
  `car_price` varchar(100) DEFAULT NULL,
  `car_age` varchar(100) DEFAULT NULL,
  `car_location` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `cars`
--

INSERT INTO `cars` (`car_id`, `car_name`, `car_nameplate`, `car_img`, `car_availability`, `car_price`, `car_age`, `car_location`) VALUES
(47, 'Hyundai Verna', 'HP01A0001', 'assets/img/carsVerna.jpg', '', '1600000', '2023', 'Panchkula'),
(48, 'Swift', 'HP01A0002', 'assets/img/carsSwift.jpg', '', '800000', '2023', 'Chandigarh'),
(49, 'Alto', 'HP01A0003', 'assets/img/carsAlto.jpg', '', '400000', '2023', 'Mohali'),
(50, 'Swift', 'HP01A0004', 'assets/img/carsSwift.jpg', '', '800000', '2023', 'Zirakpur'),
(51, 'Hyundai Verna', 'HP01A0005', 'assets/img/carsVerna.jpg', '', '1600000', '2023', 'Zirakpur'),
(52, 'Alto', 'HP01A0006', 'assets/img/carsAlto.jpg', '', '400000', '2023', 'Mohali');

-- --------------------------------------------------------

--
-- Table structure for table `clients`
--

CREATE TABLE `clients` (
  `client_username` varchar(50) NOT NULL,
  `client_name` varchar(50) NOT NULL,
  `client_phone` varchar(15) NOT NULL,
  `client_email` varchar(25) NOT NULL,
  `client_address` varchar(50) CHARACTER SET utf8 COLLATE utf8_estonian_ci NOT NULL,
  `client_password` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `clients`
--

INSERT INTO `clients` (`client_username`, `client_name`, `client_phone`, `client_email`, `client_address`, `client_password`) VALUES
('mohit01', 'mohit', '07018271214', 'guleriaaakash25@gmail.com', '61 sector phase7 hl 106', 'Aakash@123'),
('Sachin', 'Sachin', '8894179152', 'sachin1906031040@gmail.co', 'District-Kangra,Himachal Pradesh', 'Sachin#@18');

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE `customers` (
  `customer_username` varchar(50) NOT NULL,
  `customer_name` varchar(50) NOT NULL,
  `customer_phone` varchar(15) NOT NULL,
  `customer_email` varchar(25) NOT NULL,
  `customer_address` varchar(50) NOT NULL,
  `customer_password` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`customer_username`, `customer_name`, `customer_phone`, `customer_email`, `customer_address`, `customer_password`) VALUES
('aakash02', 'aakash', '09787665433', 'guleriaaakash025@gmail.co', 'iugjyugy', 'Aakash@12'),
('Aakash12', 'Aakash Guleria', '8894179152', 'sachin1906031040@gmail.co', 'Dharamshala Himachal Pradesh Pincode 176215', 'Aakash#@18'),
('rohit01', 'rohit', '07018271214', 'guleriaaakash25@gmail.com', '61 sector phase7 hl 106', 'Aaakash@12'),
('Test12', 'Test', '9876543210', 'xyz@gmail.com', 'Dharamshala Himachal Pradesh Pincode 176215', 'Test#@18');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `booked`
--
ALTER TABLE `booked`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cars`
--
ALTER TABLE `cars`
  ADD PRIMARY KEY (`car_id`),
  ADD UNIQUE KEY `car_nameplate` (`car_nameplate`);

--
-- Indexes for table `clients`
--
ALTER TABLE `clients`
  ADD PRIMARY KEY (`client_username`);

--
-- Indexes for table `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`customer_username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `booked`
--
ALTER TABLE `booked`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `cars`
--
ALTER TABLE `cars`
  MODIFY `car_id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=53;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
