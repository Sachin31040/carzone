    <?php
include('session_customer.php');
if (!isset($_SESSION['login_customer'])) {
    session_destroy();
    header("location: customerlogin.php");
}

if (isset($_POST['submit'])) {
    // Get car details from the form submission
    $car_name = $_POST['car_name'];
    $car_nameplate = $_POST['car_nameplate'];
    $car_price = $_POST['car_price'];
    $car_age = $_POST['car_age'];


    // Assuming $conn is your database connection
    // Insert the data into the "booked" table
    $sql = "INSERT INTO booked (car_name, car_nameplate, car_price, car_age) VALUES ('$car_name', '$car_nameplate', '$car_price', '$car_age')";
    $result = mysqli_query($conn, $sql);

    if ($result) {
        echo "Booking successful!";
        echo '<a href="/car-becho/index.php">Go To Home</a>';
        
        // You can redirect the user to a confirmation page if needed
    } else {
        echo "Error: " . mysqli_error($conn);
    }
}
?>
</body>
</html>

