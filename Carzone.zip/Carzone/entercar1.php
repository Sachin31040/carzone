<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $car_name = $_POST['car_name'] ?? '';
    $car_nameplate = $_POST['car_nameplate'] ?? '';
    $car_age = $_POST['car_age'] ?? '';
    $car_price = $_POST['car_price'] ?? '';
    $car_location = $_POST['car_location'] ?? '';

    $targetDirectory = "assets/img/cars"; // Directory where you want to store the uploaded files
    $targetFile = $targetDirectory . basename($_FILES["uploadedimage"]["name"]);
    $uploadOk = 1;
    $imageFileType = strtolower(pathinfo($targetFile, PATHINFO_EXTENSION));

    if (isset($_POST["submit"])) {
        $check = getimagesize($_FILES["uploadedimage"]["tmp_name"]);
        if ($check !== false) {
            echo "File is an image - " . $check["mime"] . ".";
            $uploadOk = 1;
        } else {
            echo "File is not an image.";
            $uploadOk = 0;
        }
    }

    // Allow any size of image
    $uploadOk = 1;

    if ($uploadOk == 0) {
        echo "Sorry, your file was not uploaded.";
    } else {
        if (move_uploaded_file($_FILES["uploadedimage"]["tmp_name"], $targetFile)) {
            echo "The file " . basename($_FILES["uploadedimage"]["name"]) . " has been uploaded.";

            require 'connection.php';
$conn = Connect();

            $sql = "INSERT INTO cars (car_name, car_nameplate, car_price, car_age, car_location, car_img) VALUES (?, ?, ?, ?, ?, ?)";
            
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("ssssss", $car_name, $car_nameplate, $car_price, $car_age, $car_location, $targetFile);

            if ($stmt->execute()) {
                // echo "Data inserted successfully.";
                echo '<a href="/car-becho/index.php">Go To Home</a>';

            } else {
                echo "Error: " . $sql . "<br>" . $conn->error;
            }

            $stmt->close();
            $conn->close();
        } else {
            echo "Sorry, there was an error uploading your file.";
        }
    }
}
?>